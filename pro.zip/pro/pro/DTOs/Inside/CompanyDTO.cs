﻿namespace pro.DTOs.Inside
{
    public class CompanyDTO
    {

    }
}
