﻿namespace pro.DTOs.Inside
{
    public class DepartmentDTO
    {
        public string DepartmentName { get; set; }
    }
}
