﻿namespace pro.DTOs.Inside
{
    public class DepartmentUserDTO
    {
        public string DepartmentName { get; set; }
    }
}
