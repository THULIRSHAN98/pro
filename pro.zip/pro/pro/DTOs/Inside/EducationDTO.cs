﻿namespace pro.DTOs.Inside
{
    public class EducationDTO
    { 
    public string CurrentStatus { get; set; }
    public string Qulification { get; set; }
    public string InsituteName { get; set; }
    public string Yearattained { get; set; }

    public string FieldOfStudy { get; set; }
     public string SoftSkills { get; set; }
      public string HardSkills { get; set; }
     public string Languages { get; set; }
    }
}
