﻿namespace pro.DTOs.Inside
{
    public class SkillDto
    {


        public int SkillType { get; set; }

        public string SkillName { get; set; }

    }
}
