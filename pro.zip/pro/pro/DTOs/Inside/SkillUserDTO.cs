﻿namespace pro.DTOs.Inside
{
    public class SkillUserDTO
    {
        public string SkillName { get; set; }
    }
 }



