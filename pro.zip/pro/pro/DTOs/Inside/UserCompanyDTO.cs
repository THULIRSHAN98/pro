﻿namespace pro.DTOs.Inside
{
    public class UserCompanyDTO
    {
        public int id { get; set; }
    }
}
